# react-d3 examples

[![Dependency Status](https://gemnasium.com/react-d3/react-d3-example.svg)](https://gemnasium.com/react-d3/react-d3-example)

Several examples for demontration the power of react-d3.

See `./simple` for simple usage.

See `./detail` for detail usage.

View more info in http://reactd3.org

## Development

for development mode:

```
NODE_ENV=0 webpack
```

for production mode:

```
NODE_ENV=1 webpack
```

- `webpack.map.config.js` map webpack.

- `webpack.config.js` chart with detail configuration.

- `webpack.simple.config.js` chart with simple configuration.
